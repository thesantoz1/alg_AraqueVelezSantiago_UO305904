package p0;


public class JavaA4 {

    /**
     * Criba de Eratóstenes (siglo III a. C.)
     * calcula y devuelve todos los primos hasta n
     */
    public static int[] esPrimosA4(int n) {

        boolean[] listaNumeros = new boolean[n + 1];

     
        for (int i = 0; i <= n; i++) {
            listaNumeros[i] = true;
        }

        int x = 2;
        while (x * x <= n) {
            if (listaNumeros[x]) {
                int paso = 2 * x;
                while (paso <= n) {
                    listaNumeros[paso] = false;
                    paso += x;
                }
            }
            x++;
        }

        int contPrimos = 0;

        
        for (int i = 2; i <= n; i++) {
            if (listaNumeros[i]) {
                contPrimos++;
            }
        }

        System.out.println("Hasta " + n + " hay " + contPrimos + " primos");

        
        int[] lSal = new int[contPrimos];
        int idx = 0;
        for (int i = 2; i <= n; i++) {
            if (listaNumeros[i]) {
                lSal[idx++] = i;
            }
        }

        return lSal;
    }

    public static void main(String[] args) {

        System.out.println("TIEMPOS DEL ALGORITMO A4");
        int n = 5000;

        for (int casos = 0; casos < 15; casos++) {
            long t1 = System.currentTimeMillis();
            int[] lPrimos = esPrimosA4(n);
            long t2 = System.currentTimeMillis();

            long tiempoMs = (t2 - t1);
            System.out.println("n=" + n + " *** tiempo = " + tiempoMs + " milisegundos");

            n = n * 2;
        }
    }
}
