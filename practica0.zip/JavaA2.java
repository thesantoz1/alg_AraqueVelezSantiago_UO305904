package p0;
import java.util.ArrayList;

	public class JavaA2 {

	    
	    public static boolean esPrimo(int m){
	        for (int i = 2; i < m; i++) {
	            if(m%i==0){
	                return true;
	            }
	            
	        }
	        return false;
	    }

	    public static ArrayList<Integer> listadoPrimos(int n){
	        ArrayList<Integer> lSal = new ArrayList<Integer>();
	        int contPrimos=0;
	        for (int i = 2; i < n+1; i++) {
	            if(esPrimo(i)){
	                lSal.add(i);
	                contPrimos++;
	            }
	        
	        }
	        System.out.println("Hasta "+ n + " hay" + contPrimos + "primos");
	        return lSal;
	    }
	    public static void main(String args[]){
	        System.out.println("TIEMPOS DEL ALGORITMO A2");
	        int n=5000;
	        for (int i = 0; i < 8; i++) {
	            long t1 = System.currentTimeMillis();
	            ArrayList<Integer> lPrimos = listadoPrimos(n);
	            long t2 = System.currentTimeMillis();
	            System.out.println("n="+ n + "***" + "tiempo =" + (int)(t2-t1) + "milisegundos)");
	            n=n*2;
	        }
	    }
	   
	}