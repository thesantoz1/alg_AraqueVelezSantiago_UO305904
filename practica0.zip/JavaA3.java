package p0;

import java.util.Arrays;

public class JavaA3{

	

	public static boolean esPrimoA3(int m) {
		
		for (int i = 2; i <= m / 2; i++) {
			 if (m%i==0) {
				 return false;
			 }
		            
		    
		}
		return true;
	       
	}
	     

	public static int[] listadoPrimos(int n) {
        int[] temp = new int[n]; 
        int contPrimos = 1;
        temp[0] = 2;

        for (int i = 3; i <= n; i += 2) {
            if (esPrimoA3(i)) {
                temp[contPrimos] = i;
                contPrimos++;
            }
        }

        System.out.println("Hasta " + n + " hay " + contPrimos + " primos");

        int[] lSal = new int[contPrimos];
        lSal= Arrays.copyOf(temp, contPrimos);
        return lSal;
    }

    public static void main(String[] args) {
        System.out.println("TIEMPOS DEL ALGORITMO A3");
        int n = 5000;

        for (int casos = 0; casos < 8; casos++) {
            long t1 = System.currentTimeMillis();
            int[] lPrimos = listadoPrimos(n);
            long t2 = System.currentTimeMillis();

            long tiempoMs = (t2 - t1);
            System.out.println("n=" + n + " *** tiempo = " + tiempoMs + " milisegundos");

            n = n * 2;
        }
    }
}